### v1.1 - 23.11.2024
* refactor(profile): append_exist_path's function is merged into append_path

### v1.0 - 23.10.2023
* Initial release