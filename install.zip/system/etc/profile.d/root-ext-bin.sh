append_exist_path /data/adb/magisk
append_exist_path /data/adb/ksu/bin
command -v magisk64 >/dev/null 2>&1 &&
alias magisk=magisk64