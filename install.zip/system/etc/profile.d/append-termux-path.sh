PREFIX=/data/data/com.termux/files/usr
append_path $PREFIX/bin ||
unset PREFIX
