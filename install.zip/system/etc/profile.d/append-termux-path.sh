PREFIX=/data/data/com.termux/files/usr
append_exist_path $PREFIX/bin ||
unset PREFIX
